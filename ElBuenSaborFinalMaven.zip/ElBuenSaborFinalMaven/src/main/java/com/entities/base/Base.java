package com.entities.base;

import lombok.*;

import javax.persistence.*;

import java.sql.Timestamp;
import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@MappedSuperclass
public class Base {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Temporal(TemporalType.TIMESTAMP)
    private Date ultimaActualizacion;

    @Column(columnDefinition = "boolean default false")
    private boolean oculto;

    @Column(columnDefinition = "boolean default false")
    private boolean eliminado;

	public void setUltimaActualizacion(Timestamp timestamp) {
		// TODO Auto-generated method stub
		
	}

	public void setEliminado(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public void setOculto(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
