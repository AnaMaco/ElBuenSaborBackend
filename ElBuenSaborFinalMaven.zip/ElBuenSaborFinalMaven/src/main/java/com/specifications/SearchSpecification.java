package com.specifications;

import java.sql.Date;

import org.springframework.data.jpa.domain.Specification;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class SearchSpecification <E> {
    public Specification<E> findByProperty(String propertyName, String propertyValue) {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.like(root.get(propertyName).as(String.class), "%" + propertyValue + "%");
            }
        };
    }

    public Specification<E> findByUid(String uidValue) {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.like(root.get("uid").as(String.class), uidValue);
            }
        };
    }

    public Specification<E> isNotDeleted() {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.equal(root.get("eliminado"), false);
            }
        };
    }

    public Specification<E> isNotHidden() {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.equal(root.get("oculto"), false);
            }
        };
    }

    public Specification<E> esBebida() {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.equal(root.get("esInsumo"), false);
            }
        };
    }

    public Specification<E> rubroPadre(String filter) {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.like(root.join("rubro").join("rubroPadre").get("denominacion"), "%"+ filter +"%");
            }
        };
    }

    public Specification<E> findByForeignId(String columnName, Long id){
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.equal(root.join(columnName).get("id"), id);
            }
        };
    }

    public Specification<E> findByForeignAttribute(String columnName, String propertyName, String propertyValue) {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.like(root.join(columnName).get(propertyName), "%" + propertyValue + "%");
            }
        };
    }

    public Specification<E> findByEstado(String propertyValue) {
        return new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query,
                                         CriteriaBuilder builder) {
                return builder.like(root.join("estado").get("denominacion"), "%" + propertyValue + "%");
            }
        };
    }

    public Specification<E> findBetweenDates(Date fechaInicio, Date fechaFin){
        return  new Specification<E>() {
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.between(root.<Date>get("fecha"), fechaInicio, fechaFin);
            }
        };
    }

    public Specification<E> findByOutOfStock(){
        return new Specification<E>() {
            @Override
            public Predicate toPredicate(Root<E> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder builder) {
                return builder.greaterThan(root.get("stockMinimo"), root.get("stockActual"));
            }
        };
    }

}
