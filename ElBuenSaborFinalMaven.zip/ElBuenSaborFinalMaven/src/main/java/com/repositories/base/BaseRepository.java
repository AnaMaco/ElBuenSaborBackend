package com.repositories.base;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.entities.base.Base;

public interface BaseRepository <E extends Base, ID extends Serializable> extends JpaRepository<E, ID>, JpaSpecificationExecutor<E> {
}
