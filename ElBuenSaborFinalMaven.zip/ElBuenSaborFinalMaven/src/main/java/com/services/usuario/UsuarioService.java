package com.services.usuario;

import com.entities.usuario.Usuario;
import com.services.base.BaseService;

public interface UsuarioService extends BaseService<Usuario, Long> {
    public Usuario findByUID(String uid) throws Exception;
}
